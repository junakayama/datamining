ARQUIVO: 	ceapd_XXXX.csv
DESCRIÇÃO:	Relação dos reembolsos efetuados aos deputados dentro das Cotas para Exercício da Atividade Parlamentar 
		dos Deputados no ano XXXX. Dados de anos anteriores podem ser obtidos no link
		https://dadosabertos.camara.leg.br/swagger/api.html#staticfile

ARQUIVO: 	get_cnpjs.py
DESCRIÇÃO:	Script que cria um arquivo de CNPJs dos fornecedores e faz requisições para obtenção de detalhes dos
		mesmos pela API https://www.receitaws.com.br/
